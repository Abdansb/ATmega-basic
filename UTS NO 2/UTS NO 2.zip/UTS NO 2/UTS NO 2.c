/*
 * UTS_NO_2.c
 * Created: 26/10/2022 04.07.59
 *  Author: Abdan Subekti
 */ 

#define F_CPU 16000000L
#include <avr/io.h>

void adc_init()
{
	// ADC enable ADEN bit 7
	ADCSRA |= (1 << 7); 
	// ADPS prescaler 128, 16000000/128 = 125000
	ADCSRA |= (1 <<2)|(1 << 1)|(1 << 0);
	// Mode free running, bit 7,6,5 = 0
	SFIOR &= ~(1 << 7) &~ (1 << 6) &~ (1 << 5); 
	// Tegangan referensi AREF=AVCC kapasitor eksternal
	ADMUX = (1<<REFS0);
	// single ended input ADC, PORTA0
	ADMUX |= (1 << 0); // Analog channel & gain selection bit (MUX0)
	ADMUX &= ~(1 << 5); // Right adjusted presentation adc result 	
}

// Fungsi baca ADC
/*uint16_t adc_read(uint8_t ch)
{
	ch &= 0b00000111; 
	ADMUX = (ADMUX & 0xF8)|ch;   
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	
	return (ADC);
}*/

int main(void)
{
	adc_init();
	// Start Konversi set bit ADSC, free running 25 adc clock cycles
	ADCSRA |= (1 << 6);
	DDRD = 0xff;
	DDRC = 0xff;

	while (1)
	{
		if (ADCSRA & (1 << 4)) // ADIF interrupt flag, jika adc selesai
		{
			PORTD = ADCL;
			PORTC = ADCH;
			ADCSRA |= (1 << 4);
		}
	}	
	
	
	
	
	
	
	/*uint16_t adc_result0, adc_result1;
	char int_buffer[10];
	DDRC = 0x01;
	

	adc_init();
	

	
	_delay_ms(50);
	
	while(1)
	{
		adc_result0 = adc_read(0);     

		if (adc_result0 < RES)
		PORTC = 0x01;
		else
		PORTC = 0x00;
		
		
	}*/
}